# Telco AI Fault and Alarm Management: Netcool to Automated Assurance demo

A runnable prototype that shows alarm deduplication, topology correlation, root cause analysis, anomaly detection,
fault prediction and closed-loop remediation on a synthetic multi-domain network (IP/MPLS core, DWDM, 5G RAN, FTTH, SD-WAN).

## Run it
- Local: `python backend/server.py` then open http://localhost:8080 (Python 3.9+, no packages needed).
- Docker: `docker compose up --build`, then open http://localhost:8080.
- Frontend only: open `frontend/index.html` in a browser. It falls back to an in-browser copy of the same engine.
- Tests: `python -m unittest discover -s tests`

Click a scenario button (fiber cut, cell site power loss, FTTH feeder cut, CPU spike, optical degradation, noise storm, SD-WAN degradation).
The Policy and closed loop tab sets the automation level and guardrails. The Audit tab shows every decision.
The Architecture, Policy, Audit and scorecard views need the live backend; frontend-only mode keeps the original console.

## Architecture (aligned to the HPE Automated Assurance study)
Five logical layers, from the study: (1) operations experience, (2) assurance decision and automation, (3) intelligence and analytics,
(4) data collection and persistence, (5) multi-domain environment. Logical flow:
network domains, collection and normalization, persistence and topology, analytics and correlation, service-impact assessment,
policy decision, orchestration and remediation, verification and learning. The Architecture tab in the console lists, per layer,
what is implemented and what is not.

```
SNMP / syslog / streaming sources (RAN, 5G core, IP/MPLS, optical, FTTH, SD-WAN)
  --> L4 Adapters (server.py: REST, UDP syslog)  --> normalize, validate (data contract), enrich, dedup, maintenance suppression
  --> L4 Persistence: in-memory alarm store + replayable journal
  --> L2 Correlation (2 hops, 45 s) --> ranked root cause (5 evidence factors) --> service impact and health
  --> L2 Policy decision (automation level + guardrails) --> playbook (simulated) --> verify --> rollback or close --> learn
  --> L1 Console tabs, TM Forum style alarm and ticket APIs, ticket event hub (webhooks)
```

| Endpoint | Purpose |
|---|---|
| POST /api/events | Ingest one event or a list: `{"src":"P1","type":"LINK_DOWN","proto":"SNMP"}` |
| POST /api/scenario/{fiber-cut,cell-site,pon,cpu,optical,sdwan,storm} | Inject a synthetic fault |
| POST /api/approve/{incident id} | Approve a proposed remediation (a dry run at level assist) |
| POST /api/policy | Set `level`, `min_conf`, `max_auto_customers`, `max_auto_per_min`, `dry_run`, `k` |
| POST /api/maintenance | `{"device":"P1","seconds":300}`; 0 seconds ends the window |
| POST /api/recurrence | Make the next verification window see the fault come back (tests rollback) |
| POST /api/replay | Re-inject journaled events: `{"events":[[t,"P1","LINK_DOWN","SNMP"]]}` |
| POST /api/hub | Register a webhook `{"callback":"http://host/hook"}` for ticket events |
| POST /api/auto, /api/reset | Legacy toggle (closed_loop or approval), reset state |
| GET /api/state, /api/catalog, /api/health | State, valid devices and alarm types, liveness |
| GET /api/architecture, /api/audit, /api/scorecard, /api/journal, /api/hub | Layer map, decision audit, PoC scorecard, event journal, hub status |
| GET /api/tmf/alarmManagement/v4/alarm, /api/tmf/troubleTicket/v4/troubleTicket | TM Forum style views (TMF642 and TMF621 field names, simplified, not conformance tested) |

Send a syslog line: `python tools/send_syslog.py P1 LINK_DOWN`.

## AI logic
- **Deduplication:** device plus alarm type is the key; repeats raise the Tally counter.
- **Correlation:** an alarm joins an open incident if it is within two hops of a member alarm and arrives within 45 s.
- **Ranked root cause:** score = 0.35 rules + 0.20 topology + 0.20 timing + 0.15 dependency + 0.10 history. Top three candidates are shown with every factor.
  Confidence rises with evidence count and the causal-rank gap to the runner-up.
- **Service impact and health:** services whose path crosses the root device; health starts at 100 and drops 40, 20 or 8 per worst Critical, Major or Minor alarm on the path.
- **Dynamic baseline:** event-rate threshold = mu + k sigma, with k adjustable. Linear forecast 10 s ahead.
- **Prediction:** logistic risk score on repeated optical alarms; at 0.7 or more it triggers a proactive reroute.
- **Policy levels:** observe, recommend, assist (approval runs a dry run), approval, closed_loop, self_optimize.
- **Guardrails for automatic execution:** low risk, confidence gate (or predicted risk), blast radius, rate limit, per-device action lock. A failed check holds the action for approval.
- **Verify, rollback, learn:** after the playbook the engine watches for recurrence for 4 s. Recurrence means rollback and escalation; success closes the incident.
  Outcomes update a per-alarm-type prior used in ranking. In self_optimize the confidence gate moves between 0.75 and 0.95.

## Metrics tracked
Raw events, unique alarms, incidents, noise reduction, anomalies, service health, and a PoC scorecard against the study's illustrative targets
(noise reduction 30 to 50 percent, detection time at least 50 percent lower, root-cause accuracy above 80 percent, remediation success above 90 percent,
verification automatic). Detection-time baseline (240 s) is an assumption. Replace it with Netcool history.

## Netcool to HPE Telco Automated Assurance
Netcool/OMNIbus, per IBM's 8.1.0 overview, is built from probes, ObjectServers (in-memory event store), gateways,
desktop and web event lists, administration tools, and a MIB manager. The HPE datasheet describes two principal components,
Fault Management and Performance Management, sized and configured independently. Fault Management has a Collection layer
(Adapters, IP Mediation, Filtering and Enrichment, Persistence) and a Management layer (Fault and Problem Lifecycle Management).
Component names are confirmed; what each does is inferred from its name, so verify behaviour and interfaces with HPE.
This demo covers Fault Management only. Performance Management is not modeled.

| Netcool | HPE AA component | In this demo |
|---|---|---|
| Probes | Collection: Adapters | HTTP ingest, UDP syslog, protocol tags |
| Probe rules files, MIB Manager | Collection: IP Mediation | `RULES` catalog and validation |
| Suppression and lookup automations, Impact | Collection: Filtering and Enrichment | Noise suppression, service impact, device context |
| ObjectServer event store | Collection: Persistence | In-memory store |
| ObjectServer dedup, event lists, automations | Management: Fault and Problem Lifecycle Management | Dedup, incidents, root cause, approval-gated remediation |
| Gateways | Not in the confirmed list | ITSM ticket id per incident |

Suggested path: size Fault Management first, run in parallel with Netcool, port mediation and filtering rules,
compare incidents with operator workflow, enable approval-based remediation, then cut over by region.

## Limits of this prototype
The study is a general design document, not a product specification: exact HPE components and deployment topology are unconfirmed, so this demo follows its logical
layers and behaviours, not HPE's internal implementation. Playbooks and the dry run are simulated; there is no orchestrator, NFV or slice-manager integration. 
Cloud, edge, NFV/CNF, data-center and SASE domains are not modeled. TM Forum payloads are simplified. Webhook delivery is best effort with no retry.
State is in memory and resets on restart. Topology, devices and services are hard-coded demo data. The "AI" is
transparent heuristics and statistics, not trained models. Remediation steps are simulated; nothing touches real devices.
SNMP traps are not decoded natively: forward them through snmptrapd or a collector to `/api/events`. There is no authentication.
To productionize: persistent store, discovered topology, trained models validated on replayed Netcool history, authenticated
device adapters, and an audit trail for every automated action.
