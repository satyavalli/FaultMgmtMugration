import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
from engine import Engine

def run(e, name, secs=70):
    e.run_scenario(name)
    for _ in range(secs): e.tick()

def real(e): return [i for i in e.incs if any(not a["noise"] for a in i["al"])]

class T(unittest.TestCase):
    def test_fiber_cut_root_cause_and_auto_fix(self):
        e = Engine(seed=1); run(e, "fiber-cut"); i = real(e)[0]
        self.assertEqual((i["root"]["src"], i["root"]["type"]), ("DWDM1", "LOS"))
        self.assertEqual(i["st"], "Resolved"); self.assertTrue(i["rem"]["auto"])
        self.assertEqual(set(i["imp"]), {"VPN-ACME", "VPN-BANK", "FTTH-AUSTIN"})

    def test_dedup_counts_repeats(self):
        e = Engine(seed=1); [e.ingest("P1", "LINK_DOWN") for _ in range(5)]
        a = [a for a in e.alarms if a["k"] == "P1LINK_DOWN"]
        self.assertEqual((len(a), a[0]["n"]), (1, 5))

    def test_medium_risk_waits_for_approval(self):
        e = Engine(seed=1); run(e, "cell-site", 30); i = real(e)[0]
        self.assertEqual((i["root"]["src"], i["rem"]["st"]), ("CSR1", "Proposed"))
        self.assertTrue(e.approve(i["id"]))
        for _ in range(20): e.tick()
        self.assertEqual(i["st"], "Resolved"); self.assertFalse(i["rem"]["auto"])

    def test_auto_off_never_runs_unapproved(self):
        e = Engine(auto=False, seed=1); run(e, "pon", 30); self.assertEqual(real(e)[0]["rem"]["st"], "Proposed")

    def test_prediction_triggers_proactive_fix(self):
        e = Engine(seed=1); run(e, "optical", 60)
        self.assertGreater(e.risk["DWDM1"]["p"], .7); self.assertEqual(real(e)[0]["st"], "Resolved")

    def test_noise_reduction(self):
        e = Engine(seed=1); run(e, "storm", 20)
        self.assertGreater(e.raw, 50); self.assertLess(len(real(e)), 3)

class Study(unittest.TestCase):
    """Behaviours taken from the HPE Automated Assurance study: policy levels, guardrails, verify, rollback, learning."""
    def test_ranked_candidates_carry_five_evidence_factors(self):
        e = Engine(seed=1); run(e, "fiber-cut", 5); c = real(e)[0]["cands"]
        self.assertEqual(set(c[0]["f"]), {"rules", "topology", "timing", "dependency", "history"})
        self.assertEqual((c[0]["src"], c[0]["type"]), ("DWDM1", "LOS")); self.assertGreater(c[0]["score"], c[1]["score"])

    def test_sdwan_degradation_poc(self):
        e = Engine(seed=1); run(e, "sdwan", 40); i = real(e)[0]
        self.assertEqual((i["root"]["src"], i["root"]["type"]), ("SDW1", "LINK_CONGESTION"))
        self.assertEqual((i["st"], i["imp"]), ("Resolved", ["SDWAN-RETAIL"]))

    def test_closed_loop_stages_and_audit(self):
        e = Engine(seed=1); run(e, "fiber-cut"); i = real(e)[0]
        self.assertEqual(list(i["loop"]), ["Observe", "Analyze", "Decide", "Act", "Verify", "Learn"])
        self.assertEqual({a["stage"] for a in e.audit if a["inc"] == i["id"]}, {"Observe", "Analyze", "Decide", "Act", "Verify", "Learn"})

    def test_observe_and_recommend_never_execute(self):
        for lvl in ("observe", "recommend"):
            e = Engine(seed=1); e.set_policy({"level": lvl}); run(e, "fiber-cut", 30); i = real(e)[0]
            self.assertNotEqual(i["st"], "Resolved"); self.assertFalse(e.approve(i["id"]))
            self.assertEqual(i["rem"], None) if lvl == "observe" else self.assertEqual(i["rem"]["st"], "Recommended")

    def test_assist_approval_is_dry_run_only(self):
        e = Engine(seed=1); e.set_policy({"level": "assist"}); run(e, "fiber-cut", 10); i = real(e)[0]
        self.assertTrue(e.approve(i["id"]))
        for _ in range(30): e.tick()
        self.assertEqual((i["rem"]["st"], i["st"]), ("DryRunDone", "Open")); self.assertTrue(all(a["st"] == "Open" for a in i["al"] if not a["noise"]))

    def test_blast_radius_and_rate_limit_hold_auto_execution(self):
        for p in ({"max_auto_customers": 1000}, {"max_auto_per_min": 0}):
            e = Engine(seed=1); e.set_policy(p); run(e, "fiber-cut", 30); i = real(e)[0]
            self.assertTrue(i["decision"]["action"].startswith("Held for approval")); self.assertEqual(i["rem"]["st"], "Proposed")
            self.assertTrue(e.approve(i["id"]))

    def test_action_lock_blocks_second_action_on_same_device(self):
        e = Engine(seed=1); run(e, "fiber-cut", 5); i = real(e)[0]
        e.locks["DWDM1"] = 999   # another incident holds the device
        i["rem"].update(st="Proposed"); e.set_policy({"level": "approval"})
        self.assertFalse(e.approve(i["id"]))

    def test_verification_failure_rolls_back_and_learns(self):
        e = Engine(seed=1); e.simulate_recurrence(); run(e, "fiber-cut"); i = real(e)[0]
        self.assertEqual((i["st"], i["rem"]["st"]), ("Escalated", "RolledBack")); self.assertEqual(e.learn["LOS"], {"ok": 0, "fail": 1})
        self.assertLess(e._prior("LOS"), .5); self.assertEqual(e.scorecard()["rows"][3]["ok"], False)

    def test_self_optimize_gate_stays_inside_bounds(self):
        e = Engine(seed=1); e.set_policy({"level": "self_optimize"}); g0 = e.gate; run(e, "fiber-cut"); self.assertLess(e.gate, g0); self.assertGreaterEqual(e.gate, .75)

    def test_maintenance_window_suppresses(self):
        e = Engine(seed=1); e.set_maintenance("DWDM1", 300); run(e, "fiber-cut", 20)
        self.assertTrue(all(a["st"] == "Suppressed" for a in e.alarms if a["src"] == "DWDM1")); self.assertGreater(e.suppressed, 0)
        self.assertNotEqual(real(e)[0]["root"]["src"], "DWDM1")

    def test_scorecard_and_service_health(self):
        e = Engine(seed=1); run(e, "fiber-cut", 8); self.assertEqual(e.snapshot()["svc"]["VPN-BANK"]["state"], "SLA at risk")
        for _ in range(60): e.tick()
        rows = e.scorecard()["rows"]; self.assertTrue(rows[2]["value"].startswith("100%")); self.assertEqual(e.snapshot()["svc"]["VPN-BANK"]["state"], "Healthy")

    def test_tmf_views_and_hub_events(self):
        e = Engine(seed=1); run(e, "fiber-cut", 70)
        t = e.tmf_tickets()[0]; self.assertEqual((t["@type"], t["status"]), ("TroubleTicket", "resolved")); self.assertIn("VPN-BANK", [r["id"] for r in t["relatedEntity"]])
        a = e.tmf_alarms()[-1]; self.assertIn(a["perceivedSeverity"], ("critical", "major", "minor", "indeterminate", "cleared"))
        self.assertEqual([x["eventType"] for x in e.outbox][:2], ["TroubleTicketCreateEvent", "TroubleTicketStatusChangeEvent"])

    def test_journal_replay_reproduces_root_cause(self):
        a = Engine(seed=1); run(a, "fiber-cut", 20); ev = [e for e in a.journal if e[2] != "NTP_DRIFT"]
        b = Engine(seed=2); b.replay([list(e) for e in ev if e[2] in ("LOS", "LINK_DOWN", "BGP_DOWN", "LDP_DOWN", "SERVICE_DEGRADED")])
        for _ in range(25): b.tick()
        self.assertEqual(real(b)[0]["root"]["type"], "LOS")

    def test_dynamic_baseline_k_changes_sensitivity(self):
        lo, hi = Engine(seed=1), Engine(seed=1); lo.set_policy({"k": 1}); hi.set_policy({"k": 6})
        for e in (lo, hi): run(e, "storm", 15)
        self.assertGreaterEqual(len(lo.anom), len(hi.anom))

    def test_bad_input_counted_per_source(self):
        e = Engine(seed=1)
        with self.assertRaises(ValueError): e.ingest("NOPE", "LOS", "SNMP")
        self.assertEqual(e.srch["SNMP"]["rej"], 1)

if __name__ == "__main__": unittest.main()
