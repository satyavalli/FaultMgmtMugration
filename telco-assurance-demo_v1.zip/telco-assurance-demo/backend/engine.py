"""Fault and alarm engine, structured on the five logical layers of the HPE Automated Assurance study:
 L4 data collection and persistence : adapters (server.py), normalization, enrichment, dedup, store, journal
 L3 intelligence and analytics      : dynamic baseline mu+k*sigma, logistic prediction, linear forecast
 L2 assurance decision/automation   : correlation, ranked root cause, service impact, policy, closed loop
 L1 operations experience           : frontend + TM Forum style northbound views
 L5 multi-domain environment        : synthetic RAN, 5G core, IP/MPLS, optical, FTTH and SD-WAN devices
Closed loop: Observe, Analyze, Decide, Act, Verify, Learn. Actions are simulated. Standard library only."""
import datetime, math, random, threading
from collections import deque

EDGES = [("PE1","P1"),("P1","DWDM1"),("DWDM1","P2"),("P2","PE2"),("P2","PE3"),("P1","RR1"),("P2","RR1"),
         ("AGG1","PE1"),("OLT1","AGG1"),("CSR1","PE2"),("GNB1","CSR1"),("UPF1","P2"),("SDW1","PE3"),("SDW2","PE2"),("SDW1","SDW2")]
SERVICES = {
    "VPN-ACME": {"path": ["PE1","P1","DWDM1","P2","PE2"], "c": 1200},
    "VPN-BANK": {"path": ["PE1","P1","DWDM1","P2","PE3"], "c": 3400},
    "VPN-MEDIA": {"path": ["PE3","P2","PE2"], "c": 800},
    "5G-SLICE-URLLC": {"path": ["GNB1","CSR1","PE2","P2","UPF1"], "c": 18500},
    "FTTH-AUSTIN": {"path": ["OLT1","AGG1","PE1","P1","DWDM1","P2"], "c": 9200},
    "SDWAN-RETAIL": {"path": ["SDW1","PE3","P2","PE2","SDW2"], "c": 640}}
DOMAIN = {"GNB1": "RAN", "CSR1": "RAN", "UPF1": "5G core", "DWDM1": "Optical", "OLT1": "Access (FTTH)", "SDW1": "SD-WAN", "SDW2": "SD-WAN"}
NODES = sorted({n for e in EDGES for n in e})
for n in NODES: DOMAIN.setdefault(n, "IP/MPLS transport")
ADJ = {}
for a, b in EDGES:
    ADJ.setdefault(a, []).append(b); ADJ.setdefault(b, []).append(a)

# alarm type: (causal rank, severity, text, is_noise). Higher rank = closer to root cause.
RULES = {
 "LOS": (10,"Critical","Loss of signal on optical port",0), "POWER_LOSS": (9,"Critical","Site power loss, both rectifiers down",0),
 "PON_LOS": (9,"Critical","PON port loss of signal",0), "LINK_DOWN": (8,"Critical","Interface link down",0),
 "CPU_HIGH": (7,"Major","Control-plane CPU above 90%",0), "OPTICAL_RX_LOW": (6,"Minor","Optical Rx power below threshold",0),
 "LDP_DOWN": (5,"Major","LDP session lost",0), "OSPF_FLAP": (4,"Minor","OSPF neighbor flapping",0),
 "BGP_DOWN": (4,"Major","BGP neighbor down",0), "BFD_DOWN": (3,"Major","BFD session down",0),
 "LINK_CONGESTION": (7,"Major","WAN underlay utilisation above 90%",0), "TUNNEL_LOSS_HIGH": (3,"Major","Overlay tunnel packet loss above SLA",0),
 "TUNNEL_LATENCY_HIGH": (2,"Minor","Overlay tunnel latency above SLA",0),
 "SERVICE_DEGRADED": (1,"Critical","Customer service degraded",0), "CELL_OUTAGE": (1,"Critical","gNodeB cell outage",0),
 "ONT_OFFLINE": (1,"Major","ONTs offline on PON port",0), "NTP_DRIFT": (0,"Info","NTP offset warning",1),
 "AUTH_FAIL": (0,"Info","SSH login failure",1), "INTF_FLAP_MINOR": (0,"Minor","Access port flap",1)}
NOISE = [t for t, r in RULES.items() if r[3]]
PLAYBOOKS = {
 "LOS": ("low", ["Verify adjacency loss over NETCONF","Trigger MPLS-TE fast reroute to backup LSP","Validate VPN reachability probes","Open fiber dispatch ticket in ITSM"]),
 "CPU_HIGH": ("medium", ["Snapshot process table","Apply control-plane policing profile","Confirm CPU back under 60%"]),
 "OPTICAL_RX_LOW": ("low", ["Shift LSPs off the degrading link","Schedule connector cleaning","Verify Rx power after shift"]),
 "POWER_LOSS": ("medium", ["Confirm power alarm and battery runtime","Reroute backhaul through microwave backup","Dispatch field crew with spare rectifier","Verify cell back on air"]),
 "PON_LOS": ("low", ["Run OTDR test on the PON port","Locate the feeder fault from the trace","Open fiber dispatch ticket in ITSM","Verify ONTs recover"]),
 "LINK_CONGESTION": ("low", ["Confirm tunnel loss and latency from probes","Steer affected applications to the secondary underlay","Verify jitter and loss back inside SLA","Open carrier ticket for the congested link"]),
 "_": ("low", ["Collect device diagnostics","Create ticket with enrichment attached"])}
SCENARIOS = {
 "fiber-cut": [("DWDM1","LOS","SNMP",0),("P1","LINK_DOWN","SNMP",1),("P2","LINK_DOWN","SNMP",1),("RR1","BGP_DOWN","STREAM",2),
   ("P1","LDP_DOWN","SYSLOG",2),("P2","LDP_DOWN","SYSLOG",2),("PE1","BGP_DOWN","STREAM",3),("PE2","BGP_DOWN","STREAM",3),
   ("PE3","BGP_DOWN","STREAM",4),("PE1","SERVICE_DEGRADED","STREAM",4),("DWDM1","LOS","SNMP",5),("P1","LINK_DOWN","SNMP",6)],
 "cell-site": [("CSR1","POWER_LOSS","SNMP",0),("CSR1","BFD_DOWN","SYSLOG",1),("PE2","BFD_DOWN","SYSLOG",1),
   ("GNB1","CELL_OUTAGE","STREAM",2),("GNB1","SERVICE_DEGRADED","STREAM",3),("GNB1","CELL_OUTAGE","STREAM",4)],
 "pon": [("OLT1","PON_LOS","SNMP",0),("OLT1","ONT_OFFLINE","STREAM",1),("AGG1","BFD_DOWN","SYSLOG",2),
   ("OLT1","SERVICE_DEGRADED","STREAM",3),("OLT1","ONT_OFFLINE","STREAM",4)],
 "cpu": [("P2","CPU_HIGH","SNMP",0),("P2","OSPF_FLAP","SYSLOG",1),("PE2","OSPF_FLAP","SYSLOG",2),("PE3","OSPF_FLAP","SYSLOG",2),("P2","OSPF_FLAP","SYSLOG",3)],
 "optical": [("DWDM1","OPTICAL_RX_LOW","SNMP",k * 1.5) for k in range(10)],
 "sdwan": [("SDW1","LINK_CONGESTION","STREAM",0),("SDW1","TUNNEL_LATENCY_HIGH","STREAM",1),("SDW2","TUNNEL_LATENCY_HIGH","STREAM",1),
   ("SDW1","TUNNEL_LOSS_HIGH","STREAM",2),("SDW2","TUNNEL_LOSS_HIGH","STREAM",2),("SDW1","SERVICE_DEGRADED","STREAM",3)],
 "storm": [(NODES[k % len(NODES)], NOISE[k % 3], "SYSLOG", k / 6) for k in range(60)]}


LEVELS = [("observe", "Detect and display the condition. No action is proposed."),
          ("recommend", "Suggest probable cause and action. Nothing can be executed."),
          ("assist", "Prepare the action. Operator approval runs it as a dry run only."),
          ("approval", "Execute after human confirmation."),
          ("closed_loop", "Execute automatically when every policy guardrail passes."),
          ("self_optimize", "Closed loop, and the confidence gate adapts to verified outcomes inside fixed bounds.")]
LEVEL_IDS = [l for l, _ in LEVELS]
DEFAULT_POLICY = {"level": "closed_loop", "min_conf": .8, "max_auto_customers": 20000, "max_auto_per_min": 3, "dry_run": False, "k": 3.0}
ADAPTERS = {"SNMP": "SNMP trap adapter", "SYSLOG": "Syslog adapter", "STREAM": "Streaming telemetry adapter"}
SCN_ROOT = {"fiber-cut": ("DWDM1", "LOS"), "cell-site": ("CSR1", "POWER_LOSS"), "pon": ("OLT1", "PON_LOS"),
            "cpu": ("P2", "CPU_HIGH"), "optical": ("DWDM1", "OPTICAL_RX_LOW"), "sdwan": ("SDW1", "LINK_CONGESTION")}
VERIFY_SECS = 4
FLOW = [("Network domains", "Synthetic devices and SCENARIOS; real feeds via syslog UDP and POST /api/events"),
        ("Collection and normalization", "Adapters tag the source; _ingest validates and builds the common alarm record"),
        ("Persistence and topology", "In-memory alarm store, journal for replay, EDGES graph and SERVICES dependency model"),
        ("Analytics and correlation", "Dedup, 2-hop/45 s correlation, dynamic baseline, prediction, ranked candidates"),
        ("Service-impact assessment", "Services on the root device's path, customers affected, service health score"),
        ("Policy decision", "Automation level plus guardrails: confidence, risk, blast radius, rate limit, action lock"),
        ("Orchestration and remediation", "Playbook steps (simulated). Dry-run mode available"),
        ("Verification and learning", "Recurrence check, rollback on failure, outcome priors, adaptive confidence gate")]
LOOP = ["Observe", "Analyze", "Decide", "Act", "Verify", "Learn"]
ARCH = [
 {"layer": "1. Customer and operations experience", "study": "Dashboards, service views, reports, tickets, KPIs, executive views",
  "here": "frontend/index.html tabs; TM Forum style alarm and ticket views; PoC scorecard", "status": "Implemented at demo scale",
  "gap": "No executive reports, multi-tenancy or role-based access"},
 {"layer": "2. Assurance decision and automation", "study": "Correlation, root cause, impact analysis, policies, workflows, remediation",
  "here": "engine.py: _correlate, _candidates, _svc_health, _decide, policy levels, playbooks, verify and rollback", "status": "Implemented, actions simulated",
  "gap": "No real orchestrator or NFV/slice-manager calls; playbooks are linear lists, not a workflow engine"},
 {"layer": "3. Intelligence and analytics", "study": "Baselines, anomaly detection, prediction, forecasting, recommendations",
  "here": "mu + k*sigma event-rate baseline, logistic fault risk, linear event-rate forecast, outcome priors", "status": "Statistical and rule-based, not trained ML",
  "gap": "No multivariate anomaly models, ML event clustering, capacity forecasting, drift monitoring or retraining"},
 {"layer": "4. Data collection and persistence", "study": "Events, alarms, KPIs, logs, telemetry, topology, inventory, history",
  "here": "server.py adapters (syslog UDP, REST), normalization and enrichment in _ingest, in-memory store, replayable journal", "status": "Partly implemented",
  "gap": "No time-series store, graph database, event bus, SNMP trap receiver (SNMP is a source tag), NETCONF or gNMI collectors"},
 {"layer": "5. Multi-domain environment", "study": "RAN, 5G core, transport, cloud, edge, NFV/CNF, data centers, SD-WAN, SASE",
  "here": "14 synthetic devices in 6 domains: RAN, 5G core, IP/MPLS, optical, FTTH, SD-WAN", "status": "Synthetic",
  "gap": "Cloud, edge, NFV/CNF, data center and SASE are not modeled"}]


class Engine:
    def __init__(self, auto=True, seed=None):
        self.lock = threading.RLock(); self.rng = random.Random(seed)
        self.policy = dict(DEFAULT_POLICY); self.policy["level"] = "closed_loop" if auto else "approval"
        self.epoch = datetime.datetime.now(datetime.timezone.utc); self.reset()

    @property
    def auto(self): return self.policy["level"] in ("closed_loop", "self_optimize")

    def reset(self):
        with self.lock:
            self.now = 0; self.alarms = []; self.incs = []; self.raw = 0; self.q = []; self.hist = deque(maxlen=40)
            self.cur = 0; self.m = 2.0; self.v = 1.0; self.anom = []; self.risk = {}; self.ids = 0; self.iid = 100
            self.audit = []; self.maint = {}; self.journal = deque(maxlen=5000); self.truth = []; self.srch = {}
            self.locks = {}; self.autolog = deque(); self.learn = {}; self.outbox = deque(maxlen=200)
            self.recur = False; self.suppressed = 0; self.fcst = 0.0; self.gate = self.policy["min_conf"]

    def dist(self, a, b):
        if a == b: return 0
        seen, frontier, d = {a}, [a], 0
        while frontier:
            d += 1; nxt = []
            for n in frontier:
                for m in ADJ.get(n, []):
                    if m == b: return d
                    if m not in seen: seen.add(m); nxt.append(m)
            frontier = nxt
        return 99

    def _log(self, inc, stage, actor, msg):
        self.audit.append({"t": self.now, "inc": inc, "stage": stage, "actor": actor, "msg": msg}); del self.audit[:-500]

    def _iso(self, s): return (self.epoch + datetime.timedelta(seconds=s)).strftime("%Y-%m-%dT%H:%M:%SZ")

    # ---- L4: collection, normalization, enrichment, dedup ----
    def ingest(self, src, type_, proto="STREAM"):
        with self.lock:
            s = self.srch.setdefault(proto, {"ok": 0, "rej": 0, "last": self.now})
            if src not in ADJ or type_ not in RULES:
                s["rej"] += 1   # data contract: unknown device or alarm type is rejected and counted per source
                raise ValueError(("unknown device " + str(src)) if src not in ADJ else ("unknown alarm type " + str(type_)))
            self._ingest(src, type_, proto)

    def _ingest(self, src, type_, proto):
        s = self.srch.setdefault(proto, {"ok": 0, "rej": 0, "last": self.now}); s["ok"] += 1; s["last"] = self.now
        self.raw += 1; self.cur += 1; self.journal.append((self.now, src, type_, proto)); k = src + type_
        ex = next((a for a in self.alarms if a["k"] == k and a["st"] != "Cleared"), None)
        if ex:  # deduplication: same device and alarm type increments the tally
            ex["n"] += 1; ex["last"] = self.now
            if type_ == "OPTICAL_RX_LOW" and ex["st"] != "Suppressed": self._predict(ex)
            return
        r = RULES[type_]; self.ids += 1; maint = self.maint.get(src, -1) > self.now
        a = {"id": self.ids, "k": k, "src": src, "type": type_, "sev": r[1], "text": r[2], "proto": proto, "adapter": ADAPTERS.get(proto, proto),
             "dom": DOMAIN[src], "t": self.now, "last": self.now, "n": 1, "noise": bool(r[3]), "inc": None, "st": "Suppressed" if maint else "Open"}
        self.alarms.insert(0, a); del self.alarms[1500:]
        if maint:   # filtering: maintenance state suppresses correlation and remediation
            self.suppressed += 1; self._log(None, "Collect", "filter", "Suppressed %s on %s: device in maintenance window" % (type_, src)); return
        self._correlate(a)

    # ---- L2: correlation and ranked root cause ----
    def _open(self, i): return i["st"] != "Resolved" and self.now - i["t0"] < 45

    def _correlate(self, a):
        if a["noise"]:
            i = next((i for i in self.incs if self._open(i) and any(self.dist(x["src"], a["src"]) <= 1 for x in i["al"])), None)
            if i: self._attach(i, a)
            return
        i = next((i for i in self.incs if self._open(i) and any(not x["noise"] and self.dist(x["src"], a["src"]) <= 2 for x in i["al"])), None)
        new = False
        if not i:
            self.iid += 1; new = True
            i = {"id": self.iid, "tkt": "TKT-%d" % (5000 + self.iid), "t0": self.now, "tFault": a["t"], "al": [], "st": "Open", "rem": None, "mttd": 0,
                 "loop": {"Observe": self.now}, "stage": "Observe", "decision": None, "cands": []}
            self.incs.insert(0, i); self._log(i["id"], "Observe", "engine", "Incident opened from %s on %s via %s" % (a["type"], a["src"], a["adapter"]))
        self._attach(i, a)
        if new: self._emit("TroubleTicketCreateEvent", i)
        if a["type"] == "OPTICAL_RX_LOW": self._predict(a)

    def _prior(self, t):
        l = self.learn.get(t, {"ok": 0, "fail": 0}); return (l["ok"] + 1) / (l["ok"] + l["fail"] + 2)

    def _candidates(self, i):
        nn = [x for x in i["al"] if not x["noise"]]
        if not nn: return []
        t0, t1 = min(x["t"] for x in nn), max(x["t"] for x in nn); out = []
        for x in nn:
            f = {"rules": RULES[x["type"]][0] / 10,
                 "topology": len([y for y in nn if y is not x and self.dist(x["src"], y["src"]) <= 2]) / max(1, len(nn) - 1),
                 "timing": 1 - (x["t"] - t0) / (t1 - t0 + 1),
                 "dependency": min(1, sum(1 for s in SERVICES.values() if x["src"] in s["path"]) / 3),
                 "history": self._prior(x["type"])}
            sc = .35 * f["rules"] + .2 * f["topology"] + .2 * f["timing"] + .15 * f["dependency"] + .1 * f["history"]
            out.append({"id": x["id"], "src": x["src"], "type": x["type"], "score": round(sc, 3), "f": {k: round(v, 2) for k, v in f.items()}, "_a": x})
        out.sort(key=lambda c: (-c["score"], -RULES[c["type"]][0])); return out

    def _attach(self, i, a):
        a["inc"] = i["id"]; i["al"].append(a); nn = [x for x in i["al"] if not x["noise"]]
        cands = self._candidates(i); old = i.get("root")
        i["root"] = cands[0]["_a"] if cands else i["al"][0]
        i["cands"] = [{k: v for k, v in c.items() if k != "_a"} for c in cands[:3]]
        if cands and (not old or old["id"] != i["root"]["id"]):
            c = cands[0]; self._stage(i, "Analyze", "engine", "Root cause %s on %s, score %.2f (rules %.2f, topology %.2f, timing %.2f, dependency %.2f, history %.2f)" %
                                      ((c["type"], c["src"], c["score"]) + tuple(c["f"][k] for k in ("rules", "topology", "timing", "dependency", "history"))))
        i["sev"] = next(s for s in ("Critical", "Major", "Minor", "Info") if any(x["sev"] == s for x in i["al"]))
        i["imp"] = [s for s, d in SERVICES.items() if i["root"]["src"] in d["path"]]
        i["cust"] = sum(SERVICES[s]["c"] for s in i["imp"])
        others = [RULES[x["type"]][0] for x in nn if x is not i["root"]]
        gap = max(0, RULES[i["root"]["type"]][0] - max(others)) if others else 0
        i["conf"] = min(.98, .55 + .06 * len(nn) + .04 * gap)   # more evidence and a clearer causal gap raise confidence
        if i["root"]["type"] != "SERVICE_DEGRADED": self._plan(i)

    def _svc_health(self):
        pen = {"Critical": 40, "Major": 20, "Minor": 8}; out = {}
        for n, s in SERVICES.items():
            h = 100
            for d in s["path"]:
                w = [pen.get(a["sev"], 0) for a in self.alarms if a["src"] == d and a["st"] == "Open" and not a["noise"]]
                h -= max(w) if w else 0
            h = max(0, h); out[n] = {"health": h, "cust": s["c"], "state": "Healthy" if h >= 90 else "Degraded" if h >= 70 else "SLA at risk"}
        return out

    # ---- L3: prediction ----
    def _predict(self, a):
        p = 1 / (1 + math.exp(-.5 * (a["n"] - 6)))   # logistic risk on repeated optical alarms
        self.risk[a["src"]] = {"p": p, "n": a["n"]}
        i = next((i for i in self.incs if i["id"] == a["inc"]), None)
        if i: i["pred"] = p; self._decide(i)

    # ---- L2: policy decision, closed loop ----
    def _plan(self, i):
        rt = i["root"]["type"]; lvl = self.policy["level"]; r = i["rem"]
        if r and r["st"] in ("Proposed", "Recommended") and r["rt"] != rt: r = i["rem"] = None
        if not r and lvl != "observe":
            risk, steps = PLAYBOOKS.get(rt, PLAYBOOKS["_"])
            r = i["rem"] = {"risk": risk, "steps": list(steps), "k": 0, "st": "Recommended" if lvl == "recommend" else "Proposed", "rt": rt}
        self._decide(i)

    def _decide(self, i):
        r, lvl, P = i["rem"], self.policy["level"], self.policy
        if i["root"]["type"] == "SERVICE_DEGRADED" or (r and r["st"] not in ("Proposed", "Recommended")): return
        dev = i["root"]["src"]; checks = []
        if lvl == "observe": act = "Observe only: policy level is observe"
        elif lvl == "recommend": act = "Recommend only: action shown, cannot be executed"
        elif lvl == "assist": act = "Prepared: operator approval runs a dry run"
        elif lvl == "approval": act = "Awaiting operator approval"
        else:
            pred = i["root"]["type"] == "OPTICAL_RX_LOW"
            self.autolog = deque(t for t in self.autolog if self.now - t < 60)
            checks = [("Risk is low", r["risk"] == "low"),
                      ("Predicted failure risk is at least 0.70" if pred else "Confidence is at least %.2f" % self.gate, i.get("pred", 0) >= .7 if pred else i["conf"] >= self.gate),
                      ("Blast radius at most %d customers" % P["max_auto_customers"], i["cust"] <= P["max_auto_customers"]),
                      ("Rate limit of %d automatic actions per minute" % P["max_auto_per_min"], len(self.autolog) < P["max_auto_per_min"]),
                      ("No other action holds the lock on %s" % dev, self.locks.get(dev, i["id"]) == i["id"])]
            ok = all(c[1] for c in checks)
            act = "Auto-execute: all guardrails passed" if ok else "Held for approval: " + "; ".join(n for n, c in checks if not c)
        d = {"action": act, "level": lvl, "checks": [{"name": n, "ok": bool(c)} for n, c in checks]}
        if not i["decision"] or i["decision"]["action"] != act:
            self._stage(i, "Decide", "policy", act + (" (conf %.0f%%)" % (i["conf"] * 100)))
        i["decision"] = d
        if lvl in ("closed_loop", "self_optimize") and act.startswith("Auto-execute"): self._start(i, True)

    def _start(self, i, auto, dry=False):
        r = i["rem"]
        if not r or r["st"] != "Proposed": return False
        dry = dry or self.policy["dry_run"]
        r.update(st="Running", auto=auto, dry=dry, next=self.now + 3, k=0); i["st"] = "Remediating"; self.locks[i["root"]["src"]] = i["id"]
        if auto: self.autolog.append(self.now)
        self._stage(i, "Act", "policy" if auto else "operator", "%s %s: %s" % ("Dry run of" if dry else "Executing", i["root"]["type"], " > ".join(r["steps"])))
        return True

    def _stage(self, i, stage, actor, msg):
        i["loop"].setdefault(stage, self.now); i["stage"] = stage; self._log(i["id"], stage, actor, msg)

    def _verify(self, i):
        r, root = i["rem"], i["root"]; self.locks.pop(root["src"], None); l = self.learn.setdefault(r["rt"], {"ok": 0, "fail": 0})
        if root["n"] > r["n0"]:   # recurrence: the root alarm was raised again during the verification window
            r["st"] = "RolledBack"; i["st"] = "Escalated"; l["fail"] += 1
            if self.policy["level"] == "self_optimize": self.gate = min(.95, self.gate + .05)
            self._stage(i, "Verify", "engine", "Verification failed: %s re-raised on %s (tally %d to %d). Rollback executed, escalated to operator" % (root["type"], root["src"], r["n0"], root["n"]))
            self._stage(i, "Learn", "engine", "Recorded failure for %s; prior now %.2f%s" % (r["rt"], self._prior(r["rt"]), "; gate raised to %.2f" % self.gate if self.policy["level"] == "self_optimize" else ""))
        else:
            r["st"] = "Done"; i["st"] = "Resolved"; i["t1"] = self.now; l["ok"] += 1
            for a in i["al"]: a["st"] = "Cleared"
            if self.policy["level"] == "self_optimize": self.gate = max(.75, self.gate - .01)
            self._stage(i, "Verify", "engine", "Verified: no recurrence of %s on %s for %d s. Incident closed" % (root["type"], root["src"], VERIFY_SECS))
            self._stage(i, "Learn", "engine", "Recorded success for %s; prior now %.2f%s" % (r["rt"], self._prior(r["rt"]), "; gate now %.2f" % self.gate if self.policy["level"] == "self_optimize" else ""))
        self._emit("TroubleTicketStatusChangeEvent", i)

    # ---- public controls ----
    def approve(self, inc_id):
        with self.lock:
            i = next((i for i in self.incs if i["id"] == inc_id), None); lvl = self.policy["level"]
            if not (i and i["rem"]) or lvl in ("observe", "recommend") or i["rem"]["st"] != "Proposed": return False
            if self.locks.get(i["root"]["src"], i["id"]) != i["id"]: return False
            self._log(i["id"], "Decide", "operator", "Operator approved the action"); return self._start(i, False, dry=lvl == "assist")

    def set_auto(self, v):
        with self.lock: self.policy["level"] = "closed_loop" if v else "approval"

    def set_policy(self, d):
        with self.lock:
            p = dict(self.policy)
            if "level" in d:
                if d["level"] not in LEVEL_IDS: raise ValueError("unknown level " + str(d["level"]))
                p["level"] = d["level"]
            for key, lo, hi, cast in (("min_conf", .5, .99, float), ("max_auto_customers", 0, 10 ** 7, int), ("max_auto_per_min", 0, 60, int), ("k", 1, 6, float)):
                if key in d:
                    v = cast(d[key])
                    if not lo <= v <= hi: raise ValueError("%s must be between %s and %s" % (key, lo, hi))
                    p[key] = v
            if "dry_run" in d: p["dry_run"] = bool(d["dry_run"])
            if p["min_conf"] != self.policy["min_conf"]: self.gate = p["min_conf"]
            self.policy = p; self._log(None, "Decide", "operator", "Policy updated: " + ", ".join("%s=%s" % kv for kv in sorted(d.items())))

    def set_maintenance(self, dev, secs):
        with self.lock:
            if dev not in ADJ: raise ValueError("unknown device " + str(dev))
            if secs > 0: self.maint[dev] = self.now + secs
            else: self.maint.pop(dev, None)
            self._log(None, "Collect", "operator", "Maintenance window %s on %s" % ("%d s" % secs if secs > 0 else "cleared", dev))

    def simulate_recurrence(self):
        with self.lock: self.recur = True; self._log(None, "Verify", "operator", "Armed: next verification window will see the fault come back")

    def run_scenario(self, name):
        if name not in SCENARIOS: raise ValueError("unknown scenario " + name)
        with self.lock:
            if name in SCN_ROOT: self.truth.append({"scn": name, "root": SCN_ROOT[name], "t": self.now})
            self.q += [(self.now + d, (s, t, p)) for s, t, p, d in SCENARIOS[name]]

    def replay(self, events):
        """Re-inject journaled events: [[t, src, type, proto], ...]. Times are relative to the first event."""
        ev = [(float(e[0]), e[1], e[2], e[3] if len(e) > 3 else "STREAM") for e in events]
        for _, s, t, _p in ev:
            if s not in ADJ or t not in RULES: raise ValueError("bad event %s %s" % (s, t))
        with self.lock:
            t0 = min((e[0] for e in ev), default=0); self.q += [(self.now + e[0] - t0, (e[1], e[2], e[3])) for e in ev]
            self._log(None, "Collect", "operator", "Replaying %d journaled events" % len(ev))

    def _emit(self, kind, i): self.outbox.append({"eventType": kind, "eventTime": self._iso(self.now), "event": {"troubleTicket": self._ticket(i)}})

    # ---- clock ----
    def tick(self):
        with self.lock:
            self.now += 1
            if self.rng.random() < .35: self._ingest(self.rng.choice(NODES), self.rng.choice(NOISE), "SYSLOG")
            due = [x for x in self.q if x[0] <= self.now]; self.q = [x for x in self.q if x[0] > self.now]
            for _, args in due: self._ingest(*args)
            for i in self.incs:
                r = i["rem"]
                if not r: continue
                if r["st"] == "Running" and self.now >= r["next"]:
                    r["k"] += 1; r["next"] = self.now + 3
                    if r["k"] >= len(r["steps"]):
                        self.locks.pop(i["root"]["src"], None)
                        if r["dry"]:
                            r["st"] = "DryRunDone"; i["st"] = "Open"; self._log(i["id"], "Act", "engine", "Dry run complete. Nothing was changed; incident remains open")
                        else:
                            r.update(st="Verifying", vt=self.now + VERIFY_SECS, n0=i["root"]["n"]); i["st"] = "Verifying"; self.locks[i["root"]["src"]] = i["id"]
                            self._stage(i, "Verify", "engine", "Playbook finished. Watching for recurrence for %d s" % VERIFY_SECS)
                            if self.recur: self.recur = False; self._ingest(i["root"]["src"], i["root"]["type"], "STREAM")
                elif r["st"] == "Verifying" and self.now >= r["vt"]: self._verify(i)
            z = (self.cur - self.m) / math.sqrt(self.v + 1); thr = self.m + self.policy["k"] * math.sqrt(self.v + 1)   # dynamic threshold mu + k*sigma
            self.hist.append({"c": self.cur, "z": z, "thr": thr})
            if z > self.policy["k"] and self.cur > 5: self.anom.insert(0, {"t": self.now, "c": self.cur, "z": z})
            ys = [h["c"] for h in list(self.hist)[-10:]]; n = len(ys)
            if n >= 3:
                mx, my = (n - 1) / 2, sum(ys) / n; sl = sum((x - mx) * (y - my) for x, y in enumerate(ys)) / sum((x - mx) ** 2 for x in range(n))
                self.fcst = max(0.0, my + sl * (n - 1 + 10 - mx))   # linear trend of event rate, 10 s ahead
            self.v = .9 * self.v + .1 * (self.cur - self.m) ** 2; self.m = .9 * self.m + .1 * self.cur; self.cur = 0

    # ---- L1: views ----
    def scorecard(self):
        real = [i for i in self.incs if any(not a["noise"] for a in i["al"])]; rows = []
        red = 100 * (1 - len(real) / self.raw) if self.raw else None
        rows.append({"metric": "Alarm-noise reduction", "value": None if red is None else "%.0f%%" % red, "target": "30-50% (study, illustrative)", "ok": None if red is None else red >= 30,
                     "note": "Raw events against real incidents. Dedup, suppression and correlation combined"})
        done = [t for t in self.truth if self.now - t["t"] >= 15]; hits, mt = 0, []
        for t in done:
            h = next((i for i in real if t["t"] <= i["t0"] <= t["t"] + 60 and (i["root"]["src"], i["root"]["type"]) == t["root"]), None)
            if h: hits += 1; mt.append(h["t0"] - t["t"])
        det = (100 * (1 - (sum(mt) / len(mt)) / 240)) if mt else None
        rows.append({"metric": "Detection-time reduction", "value": None if det is None else "%.0f%%" % det, "target": "At least 50%", "ok": None if det is None else det >= 50,
                     "note": "Measured %s s from fault to incident against an assumed 240 s manual baseline. Simulated clock; replace with Netcool history" % ("%.1f" % (sum(mt) / len(mt)) if mt else "-")})
        acc = 100 * hits / len(done) if done else None
        rows.append({"metric": "Root-cause ranking accuracy", "value": None if acc is None else "%.0f%% (%d of %d)" % (acc, hits, len(done)), "target": "More than 80%", "ok": None if acc is None else acc > 80,
                     "note": "Each scenario has a known true root cause. Needs at least one scenario run"})
        ok = sum(l["ok"] for l in self.learn.values()); bad = sum(l["fail"] for l in self.learn.values())
        rows.append({"metric": "Remediation success", "value": "%d of %d" % (ok, ok + bad) if ok + bad else None, "target": "More than 90%", "ok": None if not ok + bad else ok / (ok + bad) > .9,
                     "note": "Verified outcomes only. Dry runs excluded"})
        res = [i for i in real if i["st"] == "Resolved"]; auto = [i for i in res if i["rem"] and i["rem"].get("auto")]
        rows.append({"metric": "Service verification", "value": "%d of %d resolved incidents verified automatically" % (len(res), len(res)) if res else None, "target": "Completed automatically", "ok": None if not res else True,
                     "note": "%d closed by closed loop, %d after operator approval" % (len(auto), len(res) - len(auto))})
        mttr = [i["t1"] - i["t0"] for i in res]
        return {"rows": rows, "mttr": sum(mttr) / len(mttr) if mttr else None}

    def _sev(self, s): return {"Critical": "critical", "Major": "major", "Minor": "minor"}.get(s, "indeterminate")

    def tmf_alarms(self):   # field names follow TMF642 Alarm Management; simplified, not conformance tested
        kind = {"POWER_LOSS": "environmentalAlarm", "CPU_HIGH": "processingErrorAlarm", "SERVICE_DEGRADED": "qualityOfServiceAlarm", "CELL_OUTAGE": "qualityOfServiceAlarm"}
        with self.lock:
            return [{"id": str(a["id"]), "href": "/api/tmf/alarmManagement/v4/alarm/%d" % a["id"], "@type": "Alarm", "state": "cleared" if a["st"] == "Cleared" else "raised",
                     "alarmType": kind.get(a["type"], "communicationsAlarm"), "perceivedSeverity": "cleared" if a["st"] == "Cleared" else self._sev(a["sev"]),
                     "probableCause": a["type"], "specificProblem": a["text"], "alarmRaisedTime": self._iso(a["t"]), "ackState": "unacknowledged",
                     "alarmedObject": {"id": a["src"], "@referredType": "ManagedEntity"}, "sourceSystemId": a["adapter"],
                     "correlatedAlarm": [{"id": str(next((i["root"]["id"] for i in self.incs if i["id"] == a["inc"]), a["id"]))}] if a["inc"] else []} for a in self.alarms[:300]]

    def _ticket(self, i):   # field names follow TMF621 Trouble Ticket; simplified, not conformance tested
        st = {"Open": "acknowledged", "Remediating": "inProgress", "Verifying": "inProgress", "Resolved": "resolved", "Escalated": "pending"}[i["st"]]
        c = i["cands"][0] if i["cands"] else None
        return {"id": i["tkt"], "href": "/api/tmf/troubleTicket/v4/troubleTicket/" + i["tkt"], "@type": "TroubleTicket", "name": "%s on %s" % (i["root"]["type"], i["root"]["src"]),
                "description": RULES[i["root"]["type"]][2], "severity": self._sev(i["sev"]), "priority": "1" if i["sev"] == "Critical" else "2" if i["sev"] == "Major" else "3",
                "status": st, "creationDate": self._iso(i["t0"]), "statusChangeReason": (i["decision"] or {}).get("action", ""),
                "relatedEntity": [{"id": s, "role": "impactedService", "@referredType": "Service"} for s in i.get("imp", [])],
                "note": [{"text": "Root cause confidence %.0f%%%s" % (i["conf"] * 100, "; score %.2f" % c["score"] if c else ""), "author": "assurance-engine"}]}

    def tmf_tickets(self):
        with self.lock: return [self._ticket(i) for i in self.incs if any(not a["noise"] for a in i["al"])]

    def snapshot(self):
        with self.lock:
            svc = self._svc_health(); rank = {"Healthy": 0, "Degraded": 1, "SLA at risk": 2}; incs = []
            for i in self.incs:
                c = {k: v for k, v in i.items() if k not in ("al", "root")}
                c["al_ids"] = [x["id"] for x in i["al"]]; c["root_id"] = i["root"]["id"]; c["rem"] = dict(i["rem"]) if i["rem"] else None
                c["sla"] = max((svc[s]["state"] for s in i.get("imp", [])), key=lambda s: rank[s], default="Healthy"); incs.append(c)
            return {"now": self.now, "raw": self.raw, "alarms": [dict(a) for a in self.alarms], "incs": incs, "hist": list(self.hist), "anom": self.anom[:20],
                    "m": self.m, "risk": self.risk, "auto": self.auto, "policy": dict(self.policy, gate=round(self.gate, 3)), "levels": LEVELS, "svc": svc,
                    "audit": self.audit[-80:][::-1], "score": self.scorecard(), "fcst": self.fcst, "suppressed": self.suppressed,
                    "maint": {d: u - self.now for d, u in self.maint.items() if u > self.now}, "learn": self.learn, "loop": LOOP,
                    "sources": {p: dict(s, status="Active" if self.now - s["last"] <= 30 else "Quiet") for p, s in self.srch.items()}, "devices": {d: DOMAIN[d] for d in NODES}}
